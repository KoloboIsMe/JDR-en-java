# JDR-en-java
Création d'un petit JDR sans interface graphique en Java dans le cadre de l'apprentissage de l'orienté objet
